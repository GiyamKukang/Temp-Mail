# Fillout The variables in Config.py further queries @riz4d 0n telegram

BOT_TOKEN = os.environ.get("BOT_TOKEN")
API_ID = int(os.environ.get("API_ID"))
API_HASH = os.environ.get("API_HASH")

# If You're hosting in VPS replace the following lines 9,10,11 hash symbol and replacing the approriate values on it and put the hash symbol before the lines 3,4,5

# BOT_TOKEN = "<your bottoken>"
# API_ID = "<your api_id>"
# API_HASH = "<your api_hash>"
